import React from 'react'
import './Header.css'
import logoImage from '../../img/logo.png'
import Clock from '../reloj/reloj';
import Login from '../Login/Login';

class Header extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <div class="row">
                    <img class="col-md-2" src={logoImage} />
                    <h1 class="col-md-6">CFD Fortune Teller<p>Let me tell you the future!</p></h1>

                    <h1 class="col-md-2 text-right"> <Clock /> </h1>
                </div>
                <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                    <a class="navbar-brand" href="#">CFD Fortune Teller</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="#">Main</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="modal" data-target="#myModal">Login</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="modal" id="myModal">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Modal Heading</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <div class="modal-body">
                                <Login isAuthenticate={true} name="Wilson" />
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default Header;