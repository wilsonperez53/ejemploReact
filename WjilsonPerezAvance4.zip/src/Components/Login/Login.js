import React from 'react'
import './Login.css';

import data from '../data/users.json'



function LoginButton(props) {
    return (
        <form className='account-form' onSubmit={(evt) => evt.preventDefault()}>
            <div className={'account-form-fields sign-in'}>
                <input id='email' name='email' type='email' placeholder='E-mail' required />
                <input id='password' name='password' type='password' placeholder='Password' required='true' />
            </div>
            <button onClick={props.onClick} className='btn-submit-form' type='submit'>
                Sign in
                </button>
        </form>
    );

}

function LogoutButton(props) {
    return (
        <button onClick={props.onClick}>
            Log out
        </button>
    );
}

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.executeLoginButtonClick = this.executeLoginButtonClick.bind(this);
        this.executeLogoutButtonClick = this.executeLogoutButtonClick.bind(this);
        this.state = { isAuthenticated: false };
    }
    executeLoginButtonClick() {
        const word = data[0].email;
        if (word === "w@gmsil.com") {
            this.setState({ isAuthenticated: true });
        }
        else
            this.setState({ isAuthenticated: false });
    }
    executeLogoutButtonClick() {
        this.setState({ isAuthenticated: false });
    }
    render() {
        const isAuthenticated = this.state.isAuthenticated;
        let button;
        if (isAuthenticated) {
            button = <LogoutButton onClick={this.executeLogoutButtonClick} />;
        } else {
            button = <LoginButton onClick={this.executeLoginButtonClick} />;
        }

        return (
            <div>
                Log in form
                {button}
            </div>
        );
    }
}

export default Login;