import React from 'react'
import './Header.css'
import logoImage from '../../img/logo.png'
import Clock from '../reloj/reloj';

function Header(props) {
    return (
        <div>
            <div class="jumbotron text-center">
                <img src={logoImage} />
                <h1>CFD Fortune Teller</h1>
                <p>Let me tell you the future!</p>
                <h1> <Clock /> </h1>
            </div>
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                <a class="navbar-brand" href="#">CFD Fortune Teller</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Main</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    );
}

export default Header;