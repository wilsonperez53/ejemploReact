import React from 'react'
import './Footer.css'

function Footer(props) {

    return (
        <div class="jumbotron text-center">
            <div className="Author">
                <p>Hecho por {props.author.name}</p>
                <p>Correo {props.author.email}</p>
            </div>
            <div className="Content">
                {props.texto}
            </div>
            <div className="Footer">
                {props.fecha}
            </div>
        </div>
    );
}

export default Footer;