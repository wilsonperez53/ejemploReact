import React from 'react'
import './Header.css'
import logoImage from '../../img/logo.png'
import Clock from '../reloj/reloj';
import Login from '../Login/Login';
import AddNewItem from '../AddNewItem/AddNewItem';

import Login2 from '../Login2/Login2';

class Header extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <div className="row">
                    <img className="col-md-2" src={logoImage} />
                    <h1 className="col-md-6">CFD Fortune Teller<p>Let me tell you the future!</p></h1>

                    <h1 className="col-md-2 text-right"> <Clock /> </h1>
                </div>
                <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
                    <a className="navbar-brand" href="#">CFD Fortune Teller</a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <a className="nav-link" href="#">Main</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" data-toggle="modal" data-target="#myModal">Login</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" data-toggle="modal" data-target="#addNewModal">Add new</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div className="modal" id="addNewModal">
                    <div className="modal-dialog">
                        <AddNewItem />
                    </div>
                </div>
                <div className="modal" id="myModal">
                    <div className="modal-dialog">
                        <div className="modal-content">

                            <div className="modal-header">
                                <h4 className="modal-title">Login with Formik</h4>
                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                            </div>

                            <div className="modal-body">

                                <Login2 nombre="Wilson" />
                            </div>

                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default Header;