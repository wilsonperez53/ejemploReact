import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header'
import MainTable from './Components/Main/Main'
import Footer from './Components/Footer/Footer'
import Listado from './Components/Listado/Listado'




function App() {
  return (
    <div>
      <Header author={{ name: "Jose", position: "editor" }} texto="Publicacion de prueba" fecha="03/13/2020" />

      <MainTable />
      <br />
      <Footer author={{ name: "Wilson Perez", email: "wilsonperez@gmail.com" }} texto="Derechos Reservados" fecha="05/18/2020" />
    </div>
  );
}
export default App;