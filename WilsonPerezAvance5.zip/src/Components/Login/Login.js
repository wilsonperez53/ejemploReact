import React from 'react'
import './Login.css';

import data from '../data/users.json'



function LoginButton(props) {
    debugger;
    return (
        <form className='account-form' onSubmit={(evt) => evt.preventDefault()}>
            <div className={'account-form-fields sign-in'}>
                <input id='email' name='email' type='email' placeholder='E-mail' required />
                <input id='password' name='password' type='password' placeholder='Password' required />
            </div>
            <button onClick={props.onClick} className='btn-submit-form' type='submit'>
                Sign in
                </button>
        </form>
    );
}

function LogoutButton(props) {
    debugger;
    return (
        <div>
            <p>Welcome {props.email}</p>
            <button onClick={props.onClick}>
                Log out
            </button>
        </div>
    );
}

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.executeLoginButtonClick = this.executeLoginButtonClick.bind(this);
        this.executeLogoutButtonClick = this.executeLogoutButtonClick.bind(this);
        this.state = { isAuthenticated: false, email: "" };
    }

    executeLoginButtonClick() {
        this.setState({ isAuthenticated: true });

    }
    executeLogoutButtonClick() {
        this.setState({ isAuthenticated: false });
    }
    render() {
        // Los parametros se envian desde el metodo render?? 
        const word = data[0].email;

        const isAuthenticated = this.state.isAuthenticated;
        let button;
        if (word === "gortiz0@mapy.cz" && isAuthenticated) {
            button = <LogoutButton onClick={this.executeLogoutButtonClick} email={word} />;
        } else {
            button = <LoginButton onClick={this.executeLoginButtonClick} />;
        }

        return (
            <div>
                Log in form
                {button}
            </div>
        );
    }
}

export default Login;